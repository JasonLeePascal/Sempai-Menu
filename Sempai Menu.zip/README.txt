We do not accept any liability for any damage caused by the use of the Sempai menu.
The use of this menu is testing your own home router!.
Your  team!

For more questions Contact Us at Sempai.Menu@Gmail.com

Wir übernehmen keinerlei Haftung für sämtliche Schäden am Sempai-Menü.
Die nutztung des Sempaimenüs ist vorgesehen um sein eigenses netztwerk zu testen!. 
Mit freundlichen Grüßen Ihr Team! 

Q:A

Q: Is It A virus:
A: No

Q: dose it  have malewhere:
A: no

Q: Is the Booter save:
A: When Your Using a VPN!

Q: is it children save
A: No 

Q:Is It Easy To Use?
A:Yes it is